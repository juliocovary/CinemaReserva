package com.mycompany.cinemafinal;

//Julio Cezar Bandeira Covary
public class AssentoInvalidoException extends Exception {
    public void impMsgAssentoInvalido() {
        System.out.println("\nNumero de assento invalido.");
    }

    public void impMsgAssentoReservado() {
        System.out.println("\nAssento ja esta reservado.");
    }
}

