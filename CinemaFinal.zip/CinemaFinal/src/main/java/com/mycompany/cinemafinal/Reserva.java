/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cinemafinal;


//Julio Cezar Bandeira Covary
public class Reserva {
    private Cliente cliente;
    private String filme;
    private String horario;
    private int assento;

    // Getters para acessar os atributos nas operações de BD
    public Cliente getCliente() {
        return cliente;
    }

    public String getFilme() {
        return filme;
    }

    public String getHorario() {
        return horario;
    }

    public int getAssento() {
        return assento;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void setFilme(String filme) {
        this.filme = filme;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public void setAssento(int assento) {
        this.assento = assento;
    }

}

