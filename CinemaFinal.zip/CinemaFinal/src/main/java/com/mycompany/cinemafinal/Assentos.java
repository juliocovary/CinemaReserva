/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cinemafinal;

//Julio Cezar Bandeira Covary
public class Assentos {
    private boolean[] assentos;

    public Assentos() {
        assentos = new boolean[25];
        for (int i = 0; i < assentos.length; i++) {
            assentos[i] = true;
        }
        // Definindo alguns assentos ja reservados
        assentos[2] = false;
        assentos[5] = false;
        assentos[15] = false;
        assentos[21] = false;
    }

    public boolean verificarDisponibilidade(int numeroAssento) throws AssentoInvalidoException {
        if (numeroAssento < 1 || numeroAssento > 25) {
            AssentoInvalidoException e = new AssentoInvalidoException();
            e.impMsgAssentoInvalido();
            throw e;
        }
        if (!assentos[numeroAssento - 1]) {
            AssentoInvalidoException e = new AssentoInvalidoException();
            e.impMsgAssentoReservado();
            throw e;
        }
        return assentos[numeroAssento - 1];
    }

    public void reservarAssento(int numeroAssento) throws AssentoInvalidoException {
        if (numeroAssento < 1 || numeroAssento > 25) {
            AssentoInvalidoException e = new AssentoInvalidoException();
            e.impMsgAssentoInvalido();
            throw e;
        }
        if (assentos[numeroAssento - 1]) {
            assentos[numeroAssento - 1] = false;
            System.out.println("Assento " + numeroAssento + " reservado com sucesso.");
        } else {
            AssentoInvalidoException e = new AssentoInvalidoException();
            e.impMsgAssentoReservado();
            throw e;
        }
    }

    public void exibirAssentos() {
        System.out.println("Assentos disponiveis:");
        for (int i = 0; i < assentos.length; i++) {
            if (assentos[i]) {
                System.out.print((i + 1) + " ");
            } else {
                System.out.print("[X] ");
            }
        }
        System.out.println();
    }
}

