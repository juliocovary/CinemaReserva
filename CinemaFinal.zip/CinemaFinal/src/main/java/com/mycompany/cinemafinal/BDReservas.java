/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cinemafinal;

import java.util.ArrayList;
import java.util.List;

// Julio Cezar Bandeira Covary
public class BDReservas {
    private List<Reserva> reservas;

    // MÉTODO SINGLETON
    private static BDReservas instance;

    public BDReservas() {
        reservas = new ArrayList<>();
    }

    // MÉTODO SINGLETON
    public static BDReservas getInstance() {
        if (instance == null) {
            instance = new BDReservas();
        }
        return instance;
    }

    // Inserção
    public void adicionarReserva(Reserva reserva) {
        reservas.add(reserva);
    }

    // Consulta
    public Reserva buscarReserva(String cpf) {
        for (Reserva reserva : reservas) {
            if (reserva.getCliente().getCpf().equals(cpf)) {
                return reserva;
            }
        }
        return null;
    }

    // Alteração
    public boolean alterarReserva(String cpf, Reserva novaReserva) {
        for (int i = 0; i < reservas.size(); i++) {
            if (reservas.get(i).getCliente().getCpf().equals(cpf)) {
                reservas.set(i, novaReserva);
                return true;
            }
        }
        return false;
    }

    // Exclusão
    public boolean excluirReserva(String cpf) {
    for (int i = 0; i < reservas.size(); i++) {
        if (reservas.get(i).getCliente().getCpf().equals(cpf)) {
            reservas.remove(i);
            return true;
        }
    }
    return false;
}

    public List<Reserva> listarReservas() {
        return reservas;
    }
}

