/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cinemafinal;

//Julio Cezar Bandeira Covary
public class Cliente extends Pessoa {
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Sobrecarga
    public void setDados(String nome, String cpf) {
        setNome(nome); 
        setCpf(cpf);   
    }

    // Sobrecarga
    public void setDados(String nome, String cpf, String email) {
        setNome(nome);    
        setCpf(cpf);     
        this.email = email;
    }
}